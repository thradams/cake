/*
 *  This file is part of cake compiler
 *  https://github.com/thradams/cake
*/

#ifdef CAKE_HEADERS

    #pragma once

    #define __STDC_VERSION_FLOAT_H__ 202311L

    #define FLT_ROUNDS      1
    #define FLT_EVAL_METHOD 0
    #define FLT_RADIX       2

    #define FLT_HAS_SUBNORM 1
    #define FLT_MANT_DIG    24
    #define FLT_DECIMAL_DIG 9
    #define FLT_DIG         6
    #define FLT_MIN_EXP     (-125)
    #define FLT_MIN_10_EXP  (-37)
    #define FLT_MAX_EXP     128
    #define FLT_MAX_10_EXP  38
    #define FLT_MAX         3.40282346638528859811704183484516925e+38F
    #define FLT_EPSILON     1.19209289550781250000000000000000000e-7F
    #define FLT_MIN         1.17549435082228750796873653722224568e-38F
    #define FLT_TRUE_MIN    1.40129846432481707092372958328991613e-45F
    #define FLT_NORM_MAX    FLT_MAX
    #define FLT_IS_IEC_60559 1

    #define DBL_HAS_SUBNORM 1
    #define DBL_MANT_DIG    53
    #define DBL_DECIMAL_DIG 17
    #define DBL_DIG         15
    #define DBL_MIN_EXP     (-1021)
    #define DBL_MIN_10_EXP  (-307)
    #define DBL_MAX_EXP     1024
    #define DBL_MAX_10_EXP  308
    #define DBL_MAX         1.79769313486231570814527423731704357e+308
    #define DBL_EPSILON     2.22044604925031308084726333618164062e-16
    #define DBL_MIN         2.22507385850720138309023271733240406e-308
    #define DBL_TRUE_MIN    4.94065645841246544176568792868221372e-324
    #define DBL_NORM_MAX    DBL_MAX
    #define DBL_IS_IEC_60559 1

    #if defined(__linux__) && defined(__x86_64__)
        /* x87 80 bits extended */
        #define LDBL_HAS_SUBNORM 1
        #define LDBL_MANT_DIG    64
        #define LDBL_DECIMAL_DIG 21
        #define LDBL_DIG         18
        #define LDBL_MIN_EXP     (-16381)
        #define LDBL_MIN_10_EXP  (-4931)
        #define LDBL_MAX_EXP     16384
        #define LDBL_MAX_10_EXP  4932
        #define LDBL_MAX         1.18973149535723176502126385303097021e+4932L
        #define LDBL_EPSILON     1.08420217248550443400745280086994171e-19L
        #define LDBL_MIN         3.36210314311209350626267781732175260e-4932L
        #define LDBL_TRUE_MIN    3.64519953188247460252840593361941982e-4951L
        #define DECIMAL_DIG      21
    #elif defined(__linux__) && defined(__aarch64__)
        /* IEEE 754 binary128 (quad), software emulated */
        #define LDBL_HAS_SUBNORM 1
        #define LDBL_MANT_DIG    113
        #define LDBL_DECIMAL_DIG 36
        #define LDBL_DIG         33
        #define LDBL_MIN_EXP     (-16381)
        #define LDBL_MIN_10_EXP  (-4931)
        #define LDBL_MAX_EXP     16384
        #define LDBL_MAX_10_EXP  4932
        #define LDBL_MAX         1.18973149535723176508575932662800702e+4932L
        #define LDBL_EPSILON     1.92592994438723585305597794258492732e-34L
        #define LDBL_MIN         3.36210314311209350626267781732175260e-4932L
        #define LDBL_TRUE_MIN    6.47517511943802511092443895822764655e-4966L
        #define DECIMAL_DIG      36
    #else
        /* long double is the same as double (msvc, macOS arm64, small targets) */
        #define LDBL_HAS_SUBNORM 1
        #define LDBL_MANT_DIG    53
        #define LDBL_DECIMAL_DIG 17
        #define LDBL_DIG         15
        #define LDBL_MIN_EXP     (-1021)
        #define LDBL_MIN_10_EXP  (-307)
        #define LDBL_MAX_EXP     1024
        #define LDBL_MAX_10_EXP  308
        #define LDBL_MAX         1.79769313486231570814527423731704357e+308L
        #define LDBL_EPSILON     2.22044604925031308084726333618164062e-16L
        #define LDBL_MIN         2.22507385850720138309023271733240406e-308L
        #define LDBL_TRUE_MIN    4.94065645841246544176568792868221372e-324L
        #define DECIMAL_DIG      17
    #endif
    #define LDBL_NORM_MAX    LDBL_MAX
    #define LDBL_IS_IEC_60559 1

#else
    #include_next <float.h>
#endif
